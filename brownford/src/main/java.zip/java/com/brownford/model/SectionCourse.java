package com.brownford.model;

import jakarta.persistence.*;

@Entity
@Table(name = "section_courses")
public class SectionCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "section_id", nullable = false)
    private Section section;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "faculty_id")
    private Faculty faculty; // Assigned faculty

    @Column(nullable = false)
    private String semester;

    @Column(nullable = false)
    private int yearLevel;

    @OneToMany(mappedBy = "sectionCourse", cascade = CascadeType.ALL, orphanRemoval = true)
    private java.util.List<Schedule> schedules;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Section getSection() {
        return section;
    }

    public void setSection(Section section) {
        this.section = section;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getYearLevel() {
        return yearLevel;
    }

    public void setYearLevel(int yearLevel) {
        this.yearLevel = yearLevel;
    }

    public java.util.List<Schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(java.util.List<Schedule> schedules) {
        this.schedules = schedules;
    }
}
