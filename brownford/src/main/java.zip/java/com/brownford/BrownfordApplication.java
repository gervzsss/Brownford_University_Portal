package com.brownford;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrownfordApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrownfordApplication.class, args);
	}

}