package com.brownford.repository;

import com.brownford.model.CurriculumCourse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CurriculumCourseRepository extends JpaRepository<CurriculumCourse, Long> {
}
