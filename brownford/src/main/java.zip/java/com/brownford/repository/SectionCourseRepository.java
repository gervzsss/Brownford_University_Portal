package com.brownford.repository;

import com.brownford.model.SectionCourse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SectionCourseRepository extends JpaRepository<SectionCourse, Long> {
}
